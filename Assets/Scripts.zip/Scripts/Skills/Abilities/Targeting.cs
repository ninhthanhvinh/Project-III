
using UnityEngine;
namespace RPG.Skills
{
    public abstract class Targeting : ScriptableObject
    { 
        public abstract void StartTargeting();
    }

}
