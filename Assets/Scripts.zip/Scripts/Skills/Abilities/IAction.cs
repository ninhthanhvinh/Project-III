﻿namespace RPG.Skills
{
    public interface IAction
    {
        void Cancel();
    }
}