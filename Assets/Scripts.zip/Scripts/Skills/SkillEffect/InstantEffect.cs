using UnityEngine;


namespace RPG.Effects
{

    [CreateAssetMenu(fileName = "InstantEffect", menuName = "Skills/New Instant Effect", order = 0)]
    public class InstantEffect : Effect
    {
        public override void ExecuteEffect(GameObject user)
        {

        }
    }
}