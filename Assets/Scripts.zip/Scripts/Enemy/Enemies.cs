using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace RPG.Enemy
{
    public abstract class Enemies : MonoBehaviour
    {
        protected LevelManager levelManager;
    }
}